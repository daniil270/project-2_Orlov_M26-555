from src.primitive_db import core


def run_test():
    print("--- Начинаем тестирование core.py ---\n")

    # 1. Создаем пустые метаданные
    metadata = {}

    # 2. Тестируем create_table
    print("1. Тест create_table:")
    res = core.create_table(metadata, "users", ["name:str", "age:int", "is_active:bool"])
    print(res)
    print("Текущие метаданные:", metadata)
    print("-" * 30)

    # 3. Тестируем insert
    print("2. Тест insert:")
    # Вставляем корректные данные
    record, error = core.insert(metadata, "users", ["Alice", "25", "true"])
    if error:
        print("Ошибка:", error)
    else:
        # Добавляем ID вручную, как это будет делать engine.py
        record["ID"] = 1
        print("Создана запись:", record)

    # Вставляем данные с ошибкой (неверный тип)
    _, error = core.insert(metadata, "users", ["Bob", "twenty", "false"])
    print("Ожидаемая ошибка:", error)
    print("-" * 30)

    # 4. Тестируем select
    print("3. Тест select:")
    # Имитируем данные, которые хранятся в таблице
    table_data = [
        {"ID": 1, "name": "Alice", "age": 25, "is_active": True},
        {"ID": 2, "name": "Bob", "age": 30, "is_active": False}
    ]

    # Без условия (должны увидеть красивую табличку)
    _, pretty_table = core.select(table_data)
    print("Все данные:\n", pretty_table)

    # С условием
    _, filtered = core.select(table_data, {"name": "Alice"})
    print("\nФильтр по name='Alice':\n", filtered)
    print("-" * 30)

    # 5. Тестируем update
    print("4. Тест update:")
    updated_data, msg = core.update(table_data, {"age": "26"}, {"name": "Alice"})
    print(msg)
    print("Данные после обновления:", updated_data)
    print("-" * 30)

    # 6. Тестируем delete
    print("5. Тест delete:")
    deleted_data, msg = core.delete(updated_data, {"name": "Bob"})
    print(msg)
    print("Данные после удаления:", deleted_data)
    print("-" * 30)


if __name__ == "__main__":
    run_test()
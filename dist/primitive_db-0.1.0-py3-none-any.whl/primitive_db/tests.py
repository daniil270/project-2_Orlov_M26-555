from src.primitive_db import utils


def run_test():
    print("--- Тест utils.py ---")

    # Тестовые данные
    data = [
        {"ID": 1, "name": "Alice", "age": 25},
        {"ID": 2, "name": "Bob", "age": 30}
    ]

    # Сохраняем
    utils.save_table_data("users", data)
    print("1. Данные успешно сохранены в data/users.json")

    # Загружаем
    loaded = utils.load_table_data("users")
    print("2. Данные успешно загружены:")
    print(loaded)

    # Проверка на несуществующую таблицу
    missing = utils.load_table_data("missing")
    if missing == []:
        print("3. Проверка несуществующей таблицы пройдена (вернулся [])")
    else:
        print("3. ОШИБКА: должна была вернуться пустая таблица")


if __name__ == "__main__":
    run_test()
